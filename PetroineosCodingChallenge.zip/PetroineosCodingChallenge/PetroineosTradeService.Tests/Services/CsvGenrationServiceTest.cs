using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using PetroineosTradeService.Config;
using PetroineosTradeService.Models;
using PetroineosTradeService.Services;

namespace PetroineosTradeService.Tests.Services
{
    [TestClass]
    public class CsvGenrationServiceTest
    {
        [TestMethod]
        public void DataProvided_FileExported()
        {
            var anyExportPath = Path.GetTempPath();
            var anyDate = DateTime.Now;
            var csvGenrationService = GetCsvGenrationService(anyDate, anyExportPath);

            csvGenrationService.Export(new List<PowerTradeGroupedDto>());

            var exportedFilePath = CsvGenrationService.GetExportFilePath(anyExportPath, CsvGenrationService.GetExportFileName(anyDate));
            Assert.IsTrue(File.Exists(exportedFilePath));
        }

        private static CsvGenrationService GetCsvGenrationService(DateTime anyDate, string exportPath)
        {
            var dateTimeService = new Mock<IDateTimeService>();
            dateTimeService.Setup(x => x.GetDateTime()).Returns(anyDate);

            var serviceConfig = new ServiceConfig() { ExportPath = exportPath };
            var option = new Mock<IOptions<ServiceConfig>>();
            option.Setup(x => x.Value).Returns(serviceConfig);

            var logger = new Mock<ILogger<CsvGenrationService>>();

            var csvGenrationService = new CsvGenrationService(logger.Object, dateTimeService.Object, option.Object);
            return csvGenrationService;
        }
    }
}