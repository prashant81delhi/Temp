﻿using Moq;
using PetroineosTradeService.Models;
using PetroineosTradeService.Services;

namespace PetroineosTradeService.Tests.Services
{
    [TestClass]
    public class TradeProcessorServiceTest
    {
        private const int ANY_NUMBER = 10;

        [TestMethod]
        public void GetPowerTradeGroupedDtos_TwoTradesTwoPeriods_FirstPeriodVolumeAggregatedCorrectly()
        {
            var firstTradeFirstPeriodVolume = 3;
            var secondTradeFirstPeriodVolume = 4;
            var powerTradeDtos = GetTwoPowerTradeDtos(firstTradeFirstPeriodVolume: firstTradeFirstPeriodVolume, secondTradeFirstPeriodVolume: secondTradeFirstPeriodVolume);
            var tradeProcessorService = GetTradeProcessorService();
            
            var PowerTradeGroupedDtos = tradeProcessorService.GetPowerTradeGroupedDtos(powerTradeDtos);

            Assert.AreEqual(firstTradeFirstPeriodVolume + secondTradeFirstPeriodVolume, PowerTradeGroupedDtos[0].Volume);
        }
        
        [TestMethod]
        public void GetPowerTradeGroupedDtos_TwoTradesTwoPeriods_SecondPeriodVolumeAggregatedCorrectly()
        {
            var firstTradeSecondPeriodVolume = 5;
            var secondTradeSecondPeriodVolume = 6;
            var powerTradeDtos = GetTwoPowerTradeDtos(firstTradeSecondPeriodVolume: firstTradeSecondPeriodVolume, secondTradeSecondPeriodVolume: secondTradeSecondPeriodVolume);
            var tradeProcessorService = GetTradeProcessorService();
            

            var PowerTradeGroupedDtos = tradeProcessorService.GetPowerTradeGroupedDtos(powerTradeDtos);

            Assert.AreEqual(firstTradeSecondPeriodVolume + secondTradeSecondPeriodVolume, PowerTradeGroupedDtos[1].Volume);
        }
        
        [TestMethod]
        public void GetPowerTradeGroupedDtos_TwoTradesTwoPeriods_TwoAggregatedPeriodsReturned()
        {
            var numberOfTradePeriods = 2;
            var powerTradeDtos = GetTwoPowerTradeDtos();
            var tradeProcessorService = GetTradeProcessorService();
            
            var PowerTradeGroupedDtos = tradeProcessorService.GetPowerTradeGroupedDtos(powerTradeDtos);

            Assert.AreEqual(numberOfTradePeriods, PowerTradeGroupedDtos.Count);
        }

        private static List<PowerTradeDto> GetTwoPowerTradeDtos(int firstTradeFirstPeriodVolume = ANY_NUMBER, int firstTradeSecondPeriodVolume = ANY_NUMBER, int secondTradeFirstPeriodVolume = ANY_NUMBER, int secondTradeSecondPeriodVolume = ANY_NUMBER)
        {
            var anyDate = DateTime.Now;
            var powerTradeDtos = new List<PowerTradeDto>
            {
                new PowerTradeDto
                {
                    Date = anyDate,
                    Periods = new List<PeriodDto>
                    {
                        new PeriodDto { Period = 1, Volume = firstTradeFirstPeriodVolume },
                        new PeriodDto { Period = 2, Volume = firstTradeSecondPeriodVolume }
                    }
                },
                new PowerTradeDto
                {
                    Date = anyDate,
                    Periods = new List<PeriodDto>
                    {
                        new PeriodDto { Period = 1, Volume = secondTradeFirstPeriodVolume },
                        new PeriodDto { Period = 2, Volume = secondTradeSecondPeriodVolume }
                    }
                },
            };
            return powerTradeDtos;
        }

        private static TradeProcessorService GetTradeProcessorService()
        {
            var tradeDataService = new Mock<ITradeDataService>();
            var csvGenrationService = new Mock<ICsvGenrationService>();
            var dateTimeService = new Mock<IDateTimeService>();
            dateTimeService.Setup(x => x.Parse(It.IsAny<string>())).Returns(DateTime.Parse(TradeProcessorService.START_TIME));
            var tradeProcessorService =
                new TradeProcessorService(tradeDataService.Object, csvGenrationService.Object, dateTimeService.Object);
            return tradeProcessorService;
        }
    }
}
