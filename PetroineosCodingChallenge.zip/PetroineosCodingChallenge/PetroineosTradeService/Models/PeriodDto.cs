﻿
namespace PetroineosTradeService.Models
{
    public class PeriodDto
    {
        public int Period { get; set; }
        public double Volume { get; set; }
    }
}
