﻿using CsvHelper.Configuration.Attributes;

namespace PetroineosTradeService.Models
{
    public class PowerTradeGroupedDto
    {
        [Name("Local Time")]
        [Format("HH:mm")]
        public DateTime LocalTime { get; set; }
        public double Volume { get; set; }
    }
}
