﻿namespace PetroineosTradeService.Models
{
    public class PowerTradeDto
    {
        public DateTime Date { get; set; }
        public IEnumerable<PeriodDto> Periods { get; set; } = new List<PeriodDto>();
    }
}
