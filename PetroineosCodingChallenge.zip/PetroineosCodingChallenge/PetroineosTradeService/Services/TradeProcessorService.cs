﻿using PetroineosTradeService.Models;

namespace PetroineosTradeService.Services
{
    public interface ITradeProcessorService
    {
        Task ProcessTrade();
        IList<PowerTradeGroupedDto> GetPowerTradeGroupedDtos(IEnumerable<PowerTradeDto> powerTradesDtos);
    }

    public class TradeProcessorService : ITradeProcessorService
    {
        public const string START_TIME = "23:00";
        private readonly ITradeDataService _tradeDataService;
        private readonly ICsvGenrationService _csvGenrationService;
        private readonly IDateTimeService _dateTimeService;

        public TradeProcessorService(ITradeDataService tradeDataService, ICsvGenrationService csvGenrationService, IDateTimeService dateTimeService)
        {
            _tradeDataService = tradeDataService;
            _csvGenrationService = csvGenrationService;
            _dateTimeService = dateTimeService;
        }

        public async Task ProcessTrade()
        {
            var powerTradesDtos = await _tradeDataService.GetPowerTrades();

            var aggregatedDtos = GetPowerTradeGroupedDtos(powerTradesDtos);

            _csvGenrationService.Export(aggregatedDtos);
        }

        public IList<PowerTradeGroupedDto> GetPowerTradeGroupedDtos(IEnumerable<PowerTradeDto> powerTradesDtos)
        {
            var startTime = _dateTimeService.Parse(START_TIME);
            var aggregatedDtos = new List<PowerTradeGroupedDto>();

            foreach (var powerTradesDto in powerTradesDtos)
            {
                var i = 0;
                foreach (var PeriodDto in powerTradesDto.Periods)
                {
                    if (aggregatedDtos.ElementAtOrDefault(i) == null)
                        aggregatedDtos.Add(new PowerTradeGroupedDto{ LocalTime = startTime.AddHours(i) });
                    
                    aggregatedDtos[i].Volume += PeriodDto.Volume;
                    i++;
                }
            }

            return aggregatedDtos;
        }
    }
}
