﻿using Services;
using PetroineosTradeService.Models;

namespace PetroineosTradeService.Services
{
    public interface ITradeDataService
    {
        Task<IEnumerable<PowerTradeDto>> GetPowerTrades();
    }

    public class TradeDataService : ITradeDataService
    {
        private readonly ILogger<TradeDataService> _logger;
        private readonly IPowerService _powerService;
        private readonly IDateTimeService _dateTimeService;
        private const string TRADES_MESSAGE = "Trades Get starting.";
        private const string TRADES_SUCCEDED_MESSAGE = "Trades Get succeded.";
        public TradeDataService(ILogger<TradeDataService> logger, IPowerService powerService, IDateTimeService dateTimeService)
        {
            _logger = logger;
            _powerService = powerService;
            _dateTimeService = dateTimeService;
        }

        public async Task<IEnumerable<PowerTradeDto>> GetPowerTrades()
        {
            _logger.LogInformation(TRADES_MESSAGE);
            var date = _dateTimeService.GetDateTime();
            var trades = await _powerService.GetTradesAsync(date);
            var tradesDtos = trades.Select(x => new PowerTradeDto
            {
                Periods = x.Periods.Select(period => new PeriodDto { Period = period.Period, Volume = period.Volume }),
                Date = x.Date
            });
            _logger.LogInformation(TRADES_SUCCEDED_MESSAGE);
            return tradesDtos;
        }
    }
}
